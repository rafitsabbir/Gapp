
package com.bistri.api_demo;

import java.util.ArrayList;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.filter.MessageTypeFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.util.StringUtils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import com.bistri.api_demo.SettingsDialogTransmitter;

public class AnimationView extends View {
	PacketFilter filter;
	Message message;

	static int x, y, r = 255, g = 255, b = 255;
	final static int radius = 6;
	Paint paint; // using this, we can draw on canvas
	ArrayList<Integer> pointsX = new ArrayList<Integer>();
	ArrayList<Integer> pointsY = new ArrayList<Integer>();

	private ArrayList<String> messages = new ArrayList<String>();
	private SettingsDialogTransmitter mDialog;
	private Handler mHandler = new Handler();
	private XMPPConnection connection;
	public static String msg, posX, posY;
	public static String DEBUG_TAG = AnimationView.class.getSimpleName();
	public static String[] parts;
	public static boolean enableDraw;
	AnimationView a;

	public AnimationView(Context context) {
		super(context);
		// Dialog for getting the xmpp settings
		
//		try {
//			mDialog = new SettingsDialogTransmitter(this);
//			SettingsDialogTransmitter.start();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			Log.d(DEBUG_TAG, "connection "+ e.getCause());
//			System.out.println("ccc");
//			e.printStackTrace();
//		}
		a=this;
		
		new SettingsDialogTransmitter(a).execute();

		paint = new Paint();
		paint.setAntiAlias(true); // for smooth rendering

		enableDraw = false;
	}

	public void setConnection(XMPPConnection connection) {
		this.connection = connection;
		if (connection != null) {
			// Add a packet listener to get messages sent to us
			filter = new MessageTypeFilter(Message.Type.chat);
			connection.addPacketListener(new PacketListener() {
				public void processPacket(Packet packet) {
					message = (Message) packet;
					if (message.getBody() != null) {
						String fromName = StringUtils.parseBareAddress(message
								.getFrom());
						messages.add(fromName + ":");
						messages.add(message.getBody());

						msg = message.getBody();

						Log.d(DEBUG_TAG, "msg is " + msg);
						if (msg.length() != 0 || msg != null) {
							parts = msg.split("&");

							posX = parts[0].replace("[", "").replace("]", "");
							posY = parts[1].replace("[", "").replace("]", "");

						} else {
							Log.d(DEBUG_TAG, "msg is null");
						}
						Log.d(DEBUG_TAG, "Received x:" + posX);
						Log.d(DEBUG_TAG, "Received y:" + posY);

						// Add the incoming message to the list view
						mHandler.post(new Runnable() {
							public void run() {
								enableDraw = true;
								invalidate();
							}
						});
					}
				}
			}, filter);
		}
	}

	@Override
	public void onDraw(Canvas canvas) {
		// Log.d(DEBUG_TAG, "a1:"+c);
		paint.setARGB(255, r, g, b);
		canvas.drawCircle(50,50, radius, paint);

		if (enableDraw == true) {
			String[] s1 = posX.split((","));
			Integer[] n1 = new Integer[s1.length];
			if (s1.length != 0) {
				for (int o1 = 0; o1 < s1.length; o1++) {
					if (s1[o1] != null)
						n1[o1] = Integer.parseInt(s1[o1].trim());

					Log.d(DEBUG_TAG, "x:" + n1[o1]);

					// points1.add(Integer.parseInt(s1[o1]));
					// Log.d(DEBUG_TAG, "x:"+points1.indexOf(o1));
				}
			} else {
				Log.d(DEBUG_TAG, "S1 is null");
			}

			String[] s2 = posY.split((","));
			Integer[] n2 = new Integer[s2.length];
			if (s2.length != 0) {
				for (int o2 = 0; o2 < s2.length; o2++) {
					if (s2[o2] != null)
						n2[o2] = Integer.parseInt(s2[o2].trim());

					Log.d(DEBUG_TAG, "y:" + n2[o2]);

					// points1.add(Integer.parseInt(s1[o1]));
					// Log.d(DEBUG_TAG, "y:"+points1.indexOf(o1));
				}
			} else {
				Log.d(DEBUG_TAG, "S2 is null");
			}
			// draw
			for (int i = 0; i < n1.length; i++) {
				canvas.drawCircle(n1[i], n2[i], radius, paint);
			}

		}
	}

	// public void sendMessage() {
	// String to = "receiverid123@gmail.com";
	// String text = "auto1";
	//
	// Log.i("XMPPClientPar", "Sending text [" + text + "] to [" + to + "]");
	// Message msg = new Message(to, Message.Type.chat);
	// msg.setBody(text);
	// connection.sendPacket(msg);
	// messages.add(connection.getUser() + ":");
	// messages.add(text);
	// }

}